package com.simpliearn;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldApplcaition {
	
	public static void main(String[] args) {
		
		
//		ApplicationContext context = new ApplicationContext(context)
		SpringApplication.run(HelloWorldApplcaition.class, args);
		
	}

}
