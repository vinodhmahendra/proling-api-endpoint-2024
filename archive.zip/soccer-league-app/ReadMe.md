Objective
Create a Java application using JDBC to manage a simplified banking system.
 The application should be able to:

Add new customers.
View customer details.
Process deposits and withdrawals.
Handle batch updates for transactions.
Manage transactions with commit and rollback operations.