package com.simplilearn.cient;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.simplilearn.config.DatabaseConnection;

public class CallableStatementExample {

	public static void main(String[] args) {
		try (Connection connection = DatabaseConnection.getInstance().getConnection()){
		
			String callSQL ="{CALL GetTeamPoints(?,?)}";

			try (CallableStatement cstmt = connection.prepareCall(callSQL)){
				cstmt.setInt(1, 3);
				cstmt.registerOutParameter(2, java.sql.Types.INTEGER);
				cstmt.execute();
				
				int points = cstmt.getInt(2);
				System.out.println("Team Points : " + points);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}

}
