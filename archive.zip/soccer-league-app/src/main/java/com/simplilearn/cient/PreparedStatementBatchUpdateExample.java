package com.simplilearn.cient;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.simplilearn.config.DatabaseConnection;

public class PreparedStatementBatchUpdateExample {
   

    public static void main(String[] args) {
        String insertSQL = "INSERT INTO League (TeamID, MatchesPlayed, Wins, Losses, Draws, Points) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = connection.prepareStatement(insertSQL)) {

            // Disable auto-commit mode
        	connection.setAutoCommit(false);

            // Set parameters and add to batch
//            pstmt.setInt((1, 101);
            pstmt.setInt(1, 101);
            pstmt.setInt(2, 10);
            pstmt.setInt(3, 5);
            pstmt.setInt(4, 3);
            pstmt.setInt(5, 2);
            pstmt.setInt(6, 17);
            pstmt.addBatch();

          
            pstmt.setInt(1, 102);
            pstmt.setInt(2, 10);
            pstmt.setInt(3, 6);
            pstmt.setInt(4, 2);
            pstmt.setInt(5, 2);
            pstmt.setInt(6, 20);
            pstmt.addBatch();

            pstmt.setInt(1, 103);
            pstmt.setInt(2, 10);
            pstmt.setInt(3, 4);
            pstmt.setInt(4, 4);
            pstmt.setInt(5, 2);
            pstmt.setInt(6, 14);
            pstmt.addBatch();

            // Execute the batch
            int[] updateCounts = pstmt.executeBatch();

            // Commit the transaction
            connection.commit();

            // Print the number of rows affected by each statement
            for (int count : updateCounts) {
                System.out.println("Rows affected: " + count);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
