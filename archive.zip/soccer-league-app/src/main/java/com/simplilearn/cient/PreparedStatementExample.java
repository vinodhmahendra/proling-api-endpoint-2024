package com.simplilearn.cient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.simplilearn.config.DatabaseConnection;

public class PreparedStatementExample {

	public static void main(String[] args) {

		try (Connection connection = DatabaseConnection.getInstance().getConnection()) {
//			String insertSQL = "INSERT INTO League ( TeamID, MatchesPlayed, Wins ,Losses, Draws, Points) "
//			+ "VALUES (?,?,?,?,?,?)";
//			try ( PreparedStatement pstmt = connection.prepareStatement(insertSQL)){
//				pstmt.setInt(1, 6); // team id
//				pstmt.setInt(2, 10); // MatchedPlayed
//				pstmt.setInt(3, 8);//Wins
//				pstmt.setInt(4, 1); // Losses
//				pstmt.setInt(5, 1); // Draws
//				pstmt.setInt(6, 16); //Points 
//				pstmt.executeUpdate();
//				
//			}

//			String updateSQL = "UPDATE League SET WINS =?,Points = ? WHERE TeamID = ?";
//			try ( PreparedStatement pstmt = connection.prepareStatement(updateSQL)){
//					pstmt.setInt(1, 9);
//					pstmt.setInt(2, 18);
//					pstmt.setInt(3, 6);
//					pstmt.executeUpdate();
//			}

//			String selectSQL = "select * From League WHERE TeamID = ?";
//			try ( PreparedStatement pstmt = connection.prepareStatement(selectSQL)){
//				pstmt.setInt(1, 6);
//				try ( ResultSet rs = pstmt.executeQuery()){
//					while ( rs.next() ) {
//						System.out.println("Team ID : " + rs.getInt("TeamID") + ",Points: "+rs.getInt("Points"));
//					}
//				}
//			
//			}

			String deleteSQL = "DELETE FROM League Where TeamID = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(deleteSQL)) {
				pstmt.setInt(1, 6);
				pstmt.executeUpdate();

			} 
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

}