package com.simplilearn.cient;

import java.sql.Connection;
import java.sql.SQLException;

import com.simplilearn.config.DatabaseConnection;

public class Program {

	public static void main(String[] args) {
		try {
			DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
			Connection connection = databaseConnection.getConnection();
			System.out.println("Connected to the database successfullly");
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
