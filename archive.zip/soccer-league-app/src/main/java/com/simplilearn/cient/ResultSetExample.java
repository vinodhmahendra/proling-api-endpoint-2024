package com.simplilearn.cient;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.simplilearn.config.DatabaseConnection;

public class ResultSetExample {

	public static void main(String[] args) {
		try (Connection connection = DatabaseConnection.getInstance().getConnection();
				Statement stmt = connection.createStatement()){
			String sql = "select * from  League";
			ResultSet rs = stmt.executeQuery(sql);
			
			while ( rs.next() ) {
				int leagueId = rs.getInt("LeagueID");
				int teamId  = rs.getInt("TeamID");
				int matches_played = rs.getInt("MatchesPlayed");
				int wins = rs.getInt("wins");
				int losses = rs.getInt("Losses");
				int draws  = rs.getInt("Draws");
				int points = rs.getInt("Points");
				
				System.out.println("League ID: " + leagueId);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
