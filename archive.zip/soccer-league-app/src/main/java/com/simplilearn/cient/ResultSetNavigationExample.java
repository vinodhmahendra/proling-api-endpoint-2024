package com.simplilearn.cient;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.simplilearn.config.DatabaseConnection;

public class ResultSetNavigationExample {

	public static void main(String[] args) {
		try (Connection connection = DatabaseConnection.getInstance().getConnection();
				Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
				ResultSet rs = stmt.executeQuery("select * from  League")){
			
			if ( rs.first() ) {
				System.out.println("First Row : " + rs.getInt("LeagueID"));
			}
			
			if ( rs.last()) {
				System.out.println("last Row : " + rs.getInt("LeagueID"));
			}
			
//			rs.previous() ; rs.next() ; rs.absolute(2)
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
