package com.simplilearn.cient;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.simplilearn.config.DatabaseConnection;

public class StatementExample {

	public static void main(String[] args) {
		try (Connection connection = DatabaseConnection.getInstance().getConnection();
				Statement statement = connection.createStatement()){
			
//			String insertSQL = "INSERT INTO League ( TeamID, MatchesPlayed, Wins ,Losses, Draws, Points) "
//					+ "VALUES (6,10,2,6,2,8)";
//			statement.executeUpdate(insertSQL);
			
			
//			String updateSQL = "UPDATE League SET WINS =7,Points = 19 WHERE TeamID = 6";
//			statement.executeUpdate(updateSQL);
			
			
			
//			UPDATE League SET WINS =?,Points = ? WHERE TeamID = ? dynamic query : PreparedStatement
			
			String selectSQL = "select * From League WHERE TeamID = 6";
			ResultSet rs = statement.executeQuery(selectSQL);
			
			while ( rs.next() ) {
				System.out.println("Team ID : " + rs.getInt("TeamID") + ",Points: "+rs.getInt("Points"));
			}
			
			String deleteSQL = "DELETE FROM League Where TeamID = 6";
			statement.executeUpdate(deleteSQL);
;			
		
			
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
