package com.simplilearn.cient;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.simplilearn.config.DatabaseConnection;

public class TransactionExample {

	public static void main(String[] args) {
		String insertSQL1 = "INSERT INTO League (TeamID, MatchesPlayed, Wins, Losses, Draws, Points) VALUES (?, ?, ?, ?, ?, ?)";
		String insertSQL2 = "INSERT INTO League (TeamID, MatchesPlayed, Wins, Losses, Draws, Points) VALUES (?, ?, ?, ?, ?, ?)";

		Connection connection  = null;
		try {
			connection = DatabaseConnection.getInstance().getConnection();
			PreparedStatement pstmt1 = connection.prepareStatement(insertSQL1);
			PreparedStatement pstmt2 = connection.prepareStatement(insertSQL2);
			
	

			// Disable auto-commit mode
			connection.setAutoCommit(false);

			// First insert statement
//            pstmt1.setString(1, "Team N");
			pstmt1.setInt(1, 1001);
			pstmt1.setInt(2, 10);
			pstmt1.setInt(3, 5);
			pstmt1.setInt(4, 3);
			pstmt1.setInt(5, 2);
			pstmt1.setInt(6, 17);
			pstmt1.executeUpdate();

			// Simulate an error
			// Uncomment the line below to simulate an error and trigger a rollback
			if (true)
				throw new SQLException("Simulated error");

			// Second insert statement
			pstmt1.setInt(1, 1002);
			pstmt2.setInt(2, 10);
			pstmt2.setInt(3, 6);
			pstmt2.setInt(4, 2);
			pstmt2.setInt(5, 2);
			pstmt2.setInt(6, 20);
			pstmt2.executeUpdate();

			// Commit the transaction
			connection.commit();
			System.out.println("Transaction committed successfully.");

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				if (connection != null) {
					// Rollback the transaction in case of an error
					connection.rollback();
					System.out.println("Transaction rolled back due to an error.");
				}
			} catch (SQLException rollbackEx) {
				rollbackEx.printStackTrace();
			}
		} finally {
			try {
				if (connection != null) {
					// Re-enable auto-commit mode
					connection.setAutoCommit(true);
				}
			} catch (SQLException finalEx) {
				finalEx.printStackTrace();
			}
		}
	}
}
