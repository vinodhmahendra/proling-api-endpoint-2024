package com.simplilearn.service;

import java.util.List;

import com.simplilearn.model.Todo;

public interface TodoService {

	void addTodo(String description);
	void removeTodo(Integer id);
	void markCompleted(Integer id);
	List<Todo> getAllTodos();
}
