package com.simplilearn.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.simplilearn.repository.InMemoryTodoRepository;
import com.simplilearn.repository.TodoRepository;
import com.simplilearn.service.TodoService;
import com.simplilearn.service.TodoServiceImpl;

@Configuration
public class AppConfig {
	
	//NOTE  : Bean Id == Method Name (default) , @Bean(name = "beanName")
	
	
	@Bean
	public TodoRepository todoRepository() {
		return new InMemoryTodoRepository();
	}
	
	
	//setter injection 
	@Bean
	public TodoService todoServiceSetter() {
		TodoServiceImpl todoService = new TodoServiceImpl();
		todoService.setTodoRepository(todoRepository());
		return todoService;
	}
	
	//constructor injection
	@Bean
	public TodoService todoServiceConsrtuctor() {
		return new TodoServiceImpl(todoRepository());
	}
	
	//Autowired
	@Bean
	public TodoService todoServiceAuto() {
		return new TodoServiceImpl(todoRepository());
	}

}
