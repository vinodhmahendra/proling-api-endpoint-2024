package com.simplilearn;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.simplilearn.model.Todo;
import com.simplilearn.service.TodoService;

@SpringBootApplication
public class TodosAppRestApplication {
	


	public static void main(String[] args) {
		SpringApplication.run(TodosAppRestApplication.class, args);
	}

	
}
