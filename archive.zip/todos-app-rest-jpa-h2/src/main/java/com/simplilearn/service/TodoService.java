package com.simplilearn.service;

import java.util.List;
import java.util.Optional;

import com.simplilearn.model.Todo;

public interface TodoService {

	Todo addTodo(Todo todo);
	void removeTodo(Integer id);
//	void markCompleted(Integer id);
	List<Todo> getAllTodos();
	Todo findById(Integer id);
//	void updateTodoStatus(Integer id,boolean completed);
}
