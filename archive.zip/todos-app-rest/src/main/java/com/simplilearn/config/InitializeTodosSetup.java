package com.simplilearn.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.simplilearn.model.Todo;
import com.simplilearn.service.TodoService;

@Component
public class InitializeTodosSetup implements CommandLineRunner{

	@Autowired
	private TodoService todoService;
	@Override
	public void run(String... args) throws Exception {
		
		todoService.addTodo(new Todo(null, "Learn  Java", false));
		todoService.addTodo(new Todo(null, "Build a Todo Application", false));
		todoService.addTodo(new Todo(null, "Refactor code using spring and spring boot", false));
		
		
	}

}
