package com.simplilearn.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.simplilearn.model.Todo;

// InMemory == ArrayList

@Repository(value = "todoRepository") // bean id
public class InMemoryTodoRepository implements TodoRepository {

	private List<Todo> todos;
	private int nextId;

	public InMemoryTodoRepository() {
		this.todos = new ArrayList<Todo>();
		this.nextId = 0;
	}

	public Todo addTodo(Todo todo) {
		if ( todo.getId() == null ) {
			todo.setId(++nextId);
			todos.add(todo);
		}else {
			removeTodo(todo.getId());
			todos.add(todo);
		}
		return todo;
	}

	public void removeTodo(Integer id) {
		todos.removeIf(todo -> todo.getId().equals(id));
	}

	public void updateTodoStatus(Integer id, boolean completed) {
		for (Todo todo : todos) {
			if (todo.getId().equals(id)) {
				todo.setCompleted(completed);
				break;
			}
		}

	}

	public List<Todo> getAllTodos() {
		return todos;
	}

	@Override
	public Optional<Todo> findById(Integer id) {
		return todos.stream().filter(todo -> todo.getId().equals(id)).findFirst();
	}

}
