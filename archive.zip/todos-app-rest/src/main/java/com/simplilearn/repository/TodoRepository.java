package com.simplilearn.repository;

import java.util.List;
import java.util.Optional;

import com.simplilearn.model.Todo;

public interface TodoRepository {
	
	Todo addTodo(Todo  todo);
	void removeTodo(Integer id);
	void updateTodoStatus(Integer id,boolean completed);
	List<Todo> getAllTodos();
	Optional<Todo> findById(Integer id);

}
